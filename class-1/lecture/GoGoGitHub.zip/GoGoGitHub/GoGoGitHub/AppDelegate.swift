//
//  AppDelegate.swift
//  GoGoGitHub
//
//  Created by Adam Wallraff on 6/27/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

    var window: UIWindow?


    func application(application: UIApplication, didFinishLaunchingWithOptions launchOptions: [NSObject: AnyObject]?) -> Bool {
        // Override point for customization after application launch.
        return true
    }

    func application(app: UIApplication, openURL url: NSURL, options: [String : AnyObject]) -> Bool {
        print("AppDelegate - OpenURL Func URL: \(url)")
        
        GitHubOAuth.shared.tokenRequestWithCallback(url, options: SaveOptions.userDefaults) { (success) in
            
            if success{
                print("We have a token!!!!")
            }
        }
        
        return true
    }


}



//https://github.com/login/oauth/authorize?client_id=ae110d2b8d1c647a4f7f&scope=email,user
//AppDelegate - OpenURL Func URL: gogogithub://?code=d02f56d0911ca8349cbc
//Callback URL: gogogithub://?code=d02f56d0911ca8349cbc
//Temp Code: d02f56d0911ca8349cbc
//Match Range: <NSSimpleRegularExpressionCheckingResult: 0x7ff75a53e570>{0, 53}{<NSRegularExpression: 0x7ff75a53d4d0> access_token=([^&]+) 0x1}
//We have a token!!!!

Optional("ee274f92008f5b8352e6e32e0d8e94440059b505")

















