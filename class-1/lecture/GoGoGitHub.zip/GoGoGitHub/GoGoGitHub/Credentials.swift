//
//  Credentials.swift
//  GoGoGitHub
//
//  Created by Adam Wallraff on 6/27/16.
//  Copyright © 2016 Adam Wallraff. All rights reserved.
//

import Foundation

let kGitHubClientID = "ae110d2b8d1c647a4f7f"
let kGitHubClientSecret = "027dabf040aaeb5593be223d64464845e6baa374"
